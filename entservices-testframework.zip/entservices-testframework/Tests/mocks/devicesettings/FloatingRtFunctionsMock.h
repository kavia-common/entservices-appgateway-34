/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 *
 * Copyright 2022 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#pragma once

#include <gmock/gmock.h>

class floatingRtFunctionsMock : public floatingRtFunctionsImpl {
public:
    virtual ~floatingRtFunctionsMock() = default;

    MOCK_METHOD(rtError, rtRemoteLocateObject, (rtRemoteEnvironment *env, const char* str, rtObjectRef& obj, int x, remoteDisconnectCallback back, void *cbdata), (override));
    MOCK_METHOD(rtRemoteEnvironment*, rtEnvironmentGetGlobal, (), (override));
    MOCK_METHOD(rtError,rtRemoteShutdown, (rtRemoteEnvironment *env), (override));
    MOCK_METHOD(rtError,rtRemoteInit, (rtRemoteEnvironment *env), (override));
    MOCK_METHOD(rtError,rtRemoteProcessSingleItem, (), (override));
    MOCK_METHOD(char*,  rtStrError, (rtError err), (override));


};
